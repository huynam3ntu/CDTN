package ntu.nthuy.recipeapp.Model;

public class Length {
    public int number;
    public String unit;
}
