package ntu.nthuy.recipeapp.Model;

public class Us {
    public double amount;
    public String unitShort;
    public String unitLong;
}
