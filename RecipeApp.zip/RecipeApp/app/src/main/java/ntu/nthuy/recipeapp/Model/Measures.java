package ntu.nthuy.recipeapp.Model;

public class Measures {
    public Us us;
    public Metric metric;
}
